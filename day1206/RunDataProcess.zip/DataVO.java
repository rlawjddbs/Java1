package day1206;

/**
 * DataVO (Data Value Object) : ������ ó���� ���� ��ü ������ ���� Ŭ����<br>
 * 
 * @author owner
 */
public class DataVO {
	private String name; // �̸�
	private int score; // ����
	
	public DataVO() {
		name = "";
		score = 0;
		
		System.out.println("DataVO Constructor Complete!");
	} // DataVO
	
	public DataVO(String name, int score) {
		this.name = name;
		this.score = score;
	} // DataVO Overriding Use Generic
	
	public String getName() {
		return name;
	} // getName

	public void setName(String name) {
		this.name = name;
	} // setName

	public int getScore() {
		return score;
	} // getScore

	public void setScore(int score) {
		this.score = score;
	} // setScore
	
	@Override
	public String toString() {
		return name + " " + score;
	} // toString
	
} // class
